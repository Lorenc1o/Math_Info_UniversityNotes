#ifndef _DICCIONARIO_CUACS
#define _DICCIONARIO_CUACS
#include "tablahash.h"
#include "cuac.h"
using namespace std;

class DiccionarioCuacs{
    private:
        TablaHash tabla;
    public:
        void insertar(Cuac nuevo);
        void follow(string nombre);
        int numElem(){
            return tabla.numelem();
        }
};

#endif